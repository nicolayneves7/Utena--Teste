function toggleMenu(){
const menu = document.getElementById("sidebar");
menu.classList.toggle("active");
}

function login(){
window.location.href = "dashboard.html";
}

function cadastrar(){
alert("Cadastro realizado!");
window.location.href = "login.html";
}

function openSection(section){

if(section === "mensagens"){
window.location.href="mensagens.html";
}

}

/* CHAT */

function sendMessage(){

const input = document.getElementById("msgInput");
const messages = document.getElementById("messages");

if(!input || !messages) return;

if(input.value.trim() === "") return;

const div = document.createElement("div");

div.classList.add("message","my-message");

div.innerText = input.value;

messages.appendChild(div);

messages.scrollTop = messages.scrollHeight;

input.value="";

}