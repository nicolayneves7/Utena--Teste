// MENU LATERAL
function toggleMenu() {
    document.getElementById("sidebar").classList.toggle("active");
}

// SLIDESHOW
let slideIndex = 0;
showSlides();

function showSlides() {
    let slides = document.querySelectorAll(".slide");
    let dots = document.querySelectorAll(".dot");

    slides.forEach(s => s.classList.remove("active"));
    dots.forEach(d => d.classList.remove("active"));

    slideIndex++;
    if (slideIndex > slides.length) slideIndex = 1;

    slides[slideIndex - 1].classList.add("active");
    dots[slideIndex - 1].classList.add("active");

    setTimeout(showSlides, 3000);
}

function currentSlide(n) {
    slideIndex = n - 1;
    showSlides();
}